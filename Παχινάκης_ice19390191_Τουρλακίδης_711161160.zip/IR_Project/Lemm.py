import os
import nltk
nltk.download('punkt_tab')
import pandas as pd
from nltk.stem import PorterStemmer

from nltk.tokenize import word_tokenize

def preprocess_text(text):
    try:
        # Attempt to convert to string (handles potential float values)
        text_str = str(text)
    except ValueError:
        # If conversion fails, return an empty string
        return ""

    # Tokenize the text
    words = word_tokenize(text_str)

    # Stemming (without context)
    stemmer = PorterStemmer()
    stemmed_words = [stemmer.stem(word) for word in words]

    return " ".join(stemmed_words)

def process_files(filenames, output_dir, column_name):
    # Ensure the output directory exists
    os.makedirs(output_dir, exist_ok=True)

    for filename in filenames:
        # Read the CSV file
        df = pd.read_csv(filename)
        
        # Check if the column exists in the dataframe
        if column_name not in df.columns:
            print(f"Column '{column_name}' not found in {filename}. Skipping.")
            continue
        
        # Apply preprocessing to the column
        df[column_name] = df[column_name].apply(preprocess_text)

        # Construct output filename with suffix to avoid overwriting
        output_filename = f"{os.path.basename(filename)}"
        output_path = os.path.join(output_dir, output_filename)

        # Write the processed dataframe back to a new CSV
        df.to_csv(output_path, index=False)
        print(f"Processed file saved to {output_path}")

# Example usage:
filenames = ["DungeonsDragons.csv", "Underdark.csv", "DrizztDoUrden.csv", 
             "DrizztSeries.csv", "Faerun.csv", "ForgottenRealms.csv"]

output_dir = "Stemming"
text_column = "WordList"  # Assuming "WordList" column already contains tokenized words

process_files(filenames, output_dir, text_column)
