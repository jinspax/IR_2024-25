import pandas as pd
import re
import os

def process_text_data(text):
    """
    Removes long words (over 16 characters) and replaces them with empty strings.
    Also removes leading/trailing whitespaces and empty strings.

    Args:
        text (str): The input text string.

    Returns:
        str: The processed text string.
    """
    words = text.split()
    filtered_words = [word for word in words if len(word) <= 16]
    processed_text = " ".join(filtered_words)
    processed_text = processed_text.strip()  # Remove leading/trailing whitespaces
    return processed_text

def process_files(filenames, output_dir, column_name):
    """
    Reads multiple CSV files, processes the specified column by removing long words 
    and empty lines, and saves the modified data to the output directory.

    Args:
        filenames (list): List of paths to the input CSV files.
        output_dir (str): Path to the output directory.
        column_name (str): Name of the column containing the text data.
    """

    for filename in filenames:
        df = pd.read_csv(filename)

        # Apply text processing function
        df[column_name] = df[column_name].apply(process_text_data)

        # Remove rows with empty strings in the specified column
        df = df[df[column_name] != ""] 

        # Construct output file path
        output_path = os.path.join(output_dir, os.path.basename(filename)) 

        df.to_csv(output_path, index=False)

# Example usage:
filenames = ["DungeonsDragons.csv","Underdark.csv","DrizztDoUrden.csv", "DrizztSeries.csv","Faerun.csv","ForgottenRealms.csv"]
output_dir = "ProcessedFiles"
text_column = "WordList"

process_files(filenames, output_dir, text_column)