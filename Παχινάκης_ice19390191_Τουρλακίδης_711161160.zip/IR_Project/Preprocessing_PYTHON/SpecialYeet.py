import pandas as pd
import re
import os

def remove_special_characters_from_files(filenames, output_dir, column_name):
    """
    Reads multiple CSV files, removes special characters from a specified column, 
    and saves the modified data to the output directory with the original filenames.

    Args:
        filenames (list): List of paths to the input CSV files.
        output_dir (str): Path to the output directory.
        column_name (str): Name of the column containing the text data.
    """

    def remove_special_characters(text):
        if pd.isna(text):  # Check for missing values (NaN)
            return ""
        else:
            return re.sub(r"[^a-zA-Z\s]", "", str(text))  # Convert to string before applying regex

    for filename in filenames:
        df = pd.read_csv(filename)

        # Check data type of the column
        if df[column_name].dtypes != 'object' and df[column_name].dtypes != 'str':
            df[column_name] = df[column_name].astype(str)  # Convert to string if necessary

        df[column_name] = df[column_name].apply(remove_special_characters)

        # Construct output file path
        output_path = os.path.join(output_dir, os.path.basename(filename)) 

        df.to_csv(output_path, index=False)

# Example usage:
filenames = ["DungeonsDragons.csv","Underdark.csv","DrizztDoUrden.csv", "DrizztSeries.csv","Faerun.csv","ForgottenRealms.csv"]
output_dir = "SpecialCharactersYeet"
text_column = "WordList"

remove_special_characters_from_files(filenames, output_dir, text_column)