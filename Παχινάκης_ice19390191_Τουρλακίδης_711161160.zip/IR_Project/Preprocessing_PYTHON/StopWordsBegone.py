import pandas as pd
from nltk.corpus import stopwords

def remove_stopwords_from_files(filenames, output_dir, column_name):


    stop_words = set(stopwords.words('english'))

    def remove_stopwords(text):
        try:
            # Attempt to convert to string (handles potential float values)
            text_str = str(text)
        except ValueError:
            # If conversion fails, return an empty string
            return ""

        words = text_str.split()
        filtered_words = [word for word in words if word.lower() not in stop_words]
        return ' '.join(filtered_words)

    for filename in filenames:
        df = pd.read_csv(filename)
        df[column_name] = df[column_name].apply(remove_stopwords)

        # Construct output filename
        output_filename = filename 
        output_path = f"{output_dir}/{output_filename}" 

        df.to_csv(output_path, index=False)

# Example usage:
filenames = ["DungeonsDragons.csv","Underdark.csv","DrizztDoUrden.csv", 
              "DrizztSeries.csv","Faerun.csv","ForgottenRealms.csv"]

output_dir = "StopwordsRemovedFiles"
text_column = "WordList"

remove_stopwords_from_files(filenames, output_dir, text_column)