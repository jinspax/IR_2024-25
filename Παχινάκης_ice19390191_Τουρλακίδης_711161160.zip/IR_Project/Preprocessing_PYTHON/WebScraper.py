import requests
from bs4 import BeautifulSoup
import csv

datasets = ["DungeonsDragons.csv","Underdark.csv","DrizztDoUrden.csv","DrizztSeries.csv","Faerun.csv","Forgotten_Realms.csv","","",]

# Step 1: Define the target URL
url = "https://en.wikipedia.org/wiki/Forgotten_Realms"

# Step 2: Send a GET request to the website
response = requests.get(url)

# Step 3: Parse the HTML content
soup = BeautifulSoup(response.content, "html.parser")

# Step 4: Find the data to scrape
# Example: Scrape all titles and links from 'a' tags
data = []
for link in soup.find_all("a"):
    title = link.text.strip()  # Text of the link
    href = link.get("href")   # URL of the link
    if href:  # Ensure href is not None
        data.append([title, href])

# Step 5: Save the data to a CSV file
csv_filename = "Forgotten_Realms.csv"
with open(csv_filename, mode="w", newline="", encoding="utf-8") as file:
    writer = csv.writer(file)
    writer.writerow(["Title", "Link"])  # Write header row
    writer.writerows(data)

print(f"Data saved to {csv_filename}")
