import requests
from bs4 import BeautifulSoup
import csv

files = ["DungeonsDragons.csv","Underdark.csv","DrizztDoUrden.csv",
         "DrizztSeries.csv","Faerun.csv","ForgottenRealms.csv"] 



# Function to scrape words from a URL and save them to a CSV file
def scrape_words_to_csv(url, output_csv):
    try:
        # Step 1: Send a GET request to the URL
        response = requests.get(url)
        response.raise_for_status()  # Raise an error for bad responses

        # Step 2: Parse the HTML content
        soup = BeautifulSoup(response.content, "html.parser")

        # Step 3: Extract all texts from the page
        word_list = []
        for tag in soup.find_all():
            text = tag.get_text(strip=True)  # Get text from each tag
            if text:  # Ensure the text is not empty
                words = text.split()  # Split text into individual words
                word_list.extend(words)

        # Step 4: Remove duplicates and sort words (optional)
        unique_word_list = sorted(set(word_list))
        output_csv+=".csv"
        # Step 5: Save the words to a CSV file
        with open(output_csv, mode="w", newline="", encoding="utf-8") as file:
            writer = csv.writer(file)
            writer.writerow(["WordList"])
            for word in unique_word_list:
                writer.writerow([word])

        print(f"Words successfully saved to {output_csv}")

    except requests.exceptions.RequestException as e:
        print(f"Error fetching the URL: {e}")
    except Exception as e:
        print(f"An error occurred: {e}")

# Example usage
if __name__ == "__main__":
    print("\n")
    url = input("Enter the URL to scrape: ").strip()
    print("\n")
    output_csv = input("Enter the File name: ").strip()
    print("\n")
    scrape_words_to_csv(url, output_csv)