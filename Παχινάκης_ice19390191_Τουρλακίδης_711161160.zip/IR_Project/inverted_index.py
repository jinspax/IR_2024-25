import os
import pandas as pd
from collections import defaultdict

# Path όπου βρίσκονται τα CSV αρχεία
base_path = r"C:\Users\Tour\Desktop\IR_Project"

# Ονόματα αρχείων CSV
filenames = [
    "DungeonsDragons.csv",
    "Underdark.csv",
    "DrizztDoUrden.csv",
    "DrizztSeries.csv",
    "Faerun.csv",
    "ForgottenRealms.csv",
]

# Δημιουργία λεξικού εγγράφων
documents = {}
doc_id = 1  # Ξεκινάμε τα IDs από το 1

for filename in filenames:
    file_path = os.path.join(base_path, filename)  # Συνδυασμός path και filename
    try:
        # Διαβάζουμε το CSV αρχείο
        df = pd.read_csv(file_path)

        # Υποθέτουμε ότι η στήλη 'WordList' περιέχει το κείμενο
        for WordList in df["WordList"]:
            documents[doc_id] = WordList
            doc_id += 1
    except Exception as e:
        print(f"Σφάλμα κατά τη φόρτωση του αρχείου {filename}: {e}")

# Εμφάνιση εγγράφων που φορτώθηκαν
print("Έγγραφα που φορτώθηκαν:", documents)

# Συνάρτηση για τη δημιουργία ανεστραμμένου ευρετηρίου
def build_inverted_index(documents):
    inverted_index = defaultdict(set)
    for doc_id, WordList in documents.items():
        tokens = WordList.lower().split()  # Tokenization
        for token in tokens:
            inverted_index[token].add(doc_id)
    return inverted_index

# Δημιουργία ανεστραμμένου ευρετηρίου
inverted_index = build_inverted_index(documents)
print("Ανεστραμμένο Ευρετήριο:", dict(inverted_index))
