import os
import pandas as pd
from collections import defaultdict

# Path όπου βρίσκονται τα CSV αρχεία
base_path = r"C:\Users\Tour\Desktop\IR_Project"

# Ονόματα αρχείων CSV
filenames = [
    "DungeonsDragons.csv",
    "Underdark.csv",
    "DrizztDoUrden.csv",
    "DrizztSeries.csv",
    "Faerun.csv",
    "ForgottenRealms.csv",
]

#INVERTED_INDEX

# Δημιουργία λεξικού εγγράφων με το όνομα αρχείου
documents = {}
file_mapping = {}  # Χαρτογράφηση του doc_id σε filename
doc_id = 1  # Ξεκινάμε τα IDs από το 1

for filename in filenames:
    file_path = os.path.join(base_path, filename)  # Συνδυασμός path και filename
    try:
        df = pd.read_csv(file_path)

        # Υποθέτουμε ότι η στήλη 'WordList' περιέχει το κείμενο
        for WordList in df["WordList"]:
            documents[doc_id] = WordList
            file_mapping[doc_id] = filename  # Αποθήκευση του ονόματος αρχείου για το doc_id
            doc_id += 1
    except Exception as e:
        print(f"Σφάλμα κατά τη φόρτωση του αρχείου {filename}: {e}")

# Συνάρτηση για τη δημιουργία ανεστραμμένου ευρετηρίου
def build_inverted_index(documents):
    inverted_index = defaultdict(set)
    for doc_id, content in documents.items():
        tokens = content.lower().split()  # Tokenization
        for token in tokens:
            inverted_index[token].add(doc_id)
    return inverted_index

# Δημιουργία ανεστραμμένου ευρετηρίου
inverted_index = build_inverted_index(documents)

#QUERY_PROCESSING

# Συνάρτηση για την επεξεργασία ερωτημάτων με Boolean λογική
def process_query(query, inverted_index):
    terms = query.lower().split()  # Διαχωρισμός λέξεων (tokenization)
    result_set = set()  # Αρχικοποίηση του συνόλου αποτελεσμάτων
    current_set = set()  # Προσωρινό σύνολο για λειτουργίες

    operator = None  # Αποθήκευση του τελευταίου τελεστή
    for term in terms:
        if term in ["and", "or", "not"]:  # Έλεγχος για Boolean τελεστές
            operator = term
        else:
            current_set = inverted_index.get(term, set())  # Λήψη εγγράφων για τον όρο

            # Εφαρμογή Boolean λογικής ανάλογα με τον τελεστή
            if operator == "and":
                result_set &= current_set
            elif operator == "or":
                result_set |= current_set
            elif operator == "not":
                result_set -= current_set
            else:  # Ο πρώτος όρος αρχικοποιεί το σύνολο αποτελεσμάτων
                result_set = current_set

    return result_set

#USER_INTERFACE

# Διεπαφή γραμμής εντολών για ερωτήματα χρηστών
print("Καλώς ήρθατε στον Επεξεργαστή Ερωτημάτων!")
while True:
    query = input("Εισάγετε το ερώτημά σας (ή 'exit' για έξοδο): ")
    if query.lower() == "exit":
        print("Ευχαριστούμε που χρησιμοποιήσατε τον επεξεργαστή!")
        break
    results = process_query(query, inverted_index)  # Επεξεργασία του ερωτήματος
    if results:
        print(f"Βρέθηκαν αποτελέσματα για το '{query}' σε:")
        for doc_id in results:
            filename = file_mapping.get(doc_id, f"Άγνωστο αρχείο (ID: {doc_id})")
            occurrences = sum(1 for word in documents[doc_id].lower().split() if word == query.lower())
            print(f"- Αρχείο: {filename}, Εμφανίσεις: {occurrences}")
    else:
        print(f"Δεν βρέθηκαν σχετικά έγγραφα για το '{query}'.")

